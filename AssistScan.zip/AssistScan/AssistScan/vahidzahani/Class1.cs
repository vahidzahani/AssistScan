﻿namespace vahidzahani
{
    internal class Class1
    {
    }
}